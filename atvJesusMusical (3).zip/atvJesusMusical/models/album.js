const db = require('../database/connection');

class Album {
    static getAll(callback) {
        const query = `
            SELECT albums.*, artists.name AS artist_name
            FROM albums
            LEFT JOIN artists ON albums.artist_id = artists.id
        `;
        db.all(query, callback);
    }

    static create(data, callback) {
        const query = `
            INSERT INTO albums (title, release_year, cover, artist_id)
            VALUES (?, ?, ?, ?)
        `;
        db.run(query, [data.title, data.release_year, data.cover, data.artist_id], callback);
    }

    static delete(id, callback) {
        db.run(`DELETE FROM albums WHERE id = ?`, [id], callback);
    }
}

module.exports = Album;
