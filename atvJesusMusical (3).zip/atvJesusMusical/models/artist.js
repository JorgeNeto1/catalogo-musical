const db = require('../database/connection');

class Artist {
    static getAll(callback) {
        db.all('SELECT * FROM artists', callback);
    }

    static create(data, callback) {
        db.run(
            'INSERT INTO artists (name, genre) VALUES (?, ?)',
            [data.name, data.genre],
            callback
        );
    }
}

module.exports = Artist;
