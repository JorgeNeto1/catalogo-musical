// Função para confirmar exclusão de registros
function confirmDelete(message) {
    return confirm(message || "Tem certeza que deseja excluir este item?");
}

// Função para exibir um loader ao enviar formulários
function showLoaderOnSubmit(form) {
    const loader = document.createElement('div');
    loader.className = 'loader';
    loader.innerHTML = '<p>Carregando...</p>';
    document.body.appendChild(loader);

    form.querySelector('button[type="submit"]').disabled = true;
    return true;
}

// Auto remover mensagens de alerta após alguns segundos
function autoDismissAlerts() {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        }, 3000); // 3 segundos
    });
}

// Executa no carregamento da página
document.addEventListener('DOMContentLoaded', () => {
    autoDismissAlerts();
});
