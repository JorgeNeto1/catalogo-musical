const express = require('express');
const router = express.Router();
const Album = require('../models/album');
const Artist = require('../models/artist');
const Genre = require('../models/genre'); // Importa o modelo de gêneros

// Listar todos os álbuns
router.get('/', (req, res) => {
    Album.getAll((err, albums) => {
        if (err) return res.status(500).send('Erro ao listar álbuns.');
        res.render('albums/index', { albums });
    });
});

// Formulário de novo álbum
router.get('/new', (req, res) => {
    // Buscar todos os artistas
    Artist.getAll((err, artists) => {
        if (err) return res.status(500).send('Erro ao carregar artistas.');

        // Buscar todos os gêneros
        Genre.getAll((err, genres) => {
            if (err) return res.status(500).send('Erro ao carregar gêneros.');
            
            // Renderizar a página 'albums/new' com os dados de artistas e gêneros
            res.render('albums/new', { artists, genres });
        });
    });
});

// Criar novo álbum
router.post('/', (req, res) => {
    // Criar o álbum com os dados enviados
    Album.create(req.body, (err, albumId) => {
        if (err) return res.status(500).send('Erro ao criar álbum.');

        // Verificar se gêneros foram enviados
        const genreIds = req.body.genres || [];
        genreIds.forEach((genreId) => {
            // Associa os gêneros ao álbum recém-criado
            Album.addGenre(albumId, genreId, (err) => {
                if (err) console.error('Erro ao associar gênero:', err);
            });
        });

        res.redirect('/albums');
    });
});

module.exports = router;
