const express = require('express');
const router = express.Router();
const Genre = require('../models/genre');

// Listar todos os gêneros
router.get('/', (req, res) => {
    Genre.getAll((err, genres) => {
        if (err) return res.status(500).send('Erro ao listar gêneros.');
        res.render('genres/index', { genres });
    });
});

// Formulário para adicionar novo gênero
router.get('/new', (req, res) => {
    res.render('genres/new');
});

// Criar um novo gênero
router.post('/', (req, res) => {
    Genre.create(req.body, (err) => {
        if (err) return res.status(500).send('Erro ao criar gênero.');
        res.redirect('/genres');
    });
});

// Formulário para editar um gênero
router.get('/:id/edit', (req, res) => {
    const id = req.params.id;
    Genre.getAll((err, genres) => {
        if (err) return res.status(500).send('Erro ao carregar gêneros.');
        const genre = genres.find((g) => g.id == id);
        if (!genre) return res.status(404).send('Gênero não encontrado.');
        res.render('genres/edit', { genre });
    });
});

// Atualizar um gênero
router.post('/:id', (req, res) => {
    Genre.update(req.params.id, req.body.name, (err) => {
        if (err) return res.status(500).send('Erro ao atualizar gênero.');
        res.redirect('/genres');
    });
});

// Deletar um gênero
router.post('/:id/delete', (req, res) => {
    Genre.delete(req.params.id, (err) => {
        if (err) return res.status(500).send('Erro ao excluir gênero.');
        res.redirect('/genres');
    });
});

module.exports = router;
