const express = require('express');
const router = express.Router();
const Artist = require('../models/artist');
const Album = require('../models/album');

// Listar todos os artistas
router.get('/', (req, res) => {
    Artist.getAll((err, artists) => {
        if (err) return res.status(500).send('Erro ao listar artistas.');
        res.render('artists/index', { artists });
    });
});

// Formulário para adicionar novo artista
router.get('/new', (req, res) => {
    Album.getAll((err, albums) => {
        if (err) return res.status(500).send('Erro ao carregar álbuns.');
        res.render('artists/new', { albums });
    });
});

// Criar um novo artista
router.post('/', (req, res) => {
    const artistData = {
        name: req.body.name,
        genre: req.body.genre,
    };
    Artist.create(artistData, (err) => {
        if (err) return res.status(500).send('Erro ao criar artista.');
        res.redirect('/artists');
    });
});

// Formulário para editar um artista
router.get('/:id/edit', (req, res) => {
    const id = req.params.id;
    Artist.getAll((err, artists) => {
        if (err) return res.status(500).send('Erro ao carregar artistas.');
        const artist = artists.find((a) => a.id == id);
        if (!artist) return res.status(404).send('Artista não encontrado.');
        res.render('artists/edit', { artist });
    });
});

// Atualizar um artista
router.post('/:id', (req, res) => {
    const artistData = {
        name: req.body.name,
        genre: req.body.genre,
    };
    Artist.update(req.params.id, artistData, (err) => {
        if (err) return res.status(500).send('Erro ao atualizar artista.');
        res.redirect('/artists');
    });
});

// Deletar um artista
router.post('/:id/delete', (req, res) => {
    Artist.delete(req.params.id, (err) => {
        if (err) return res.status(500).send('Erro ao excluir artista.');
        res.redirect('/artists');
    });
});

module.exports = router;
