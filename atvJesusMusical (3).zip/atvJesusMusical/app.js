const express = require('express');
const app = express();
const path = require('path');


// Configurações
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));


// Rotas
const albumRoutes = require('./routes/albums');
const artistRoutes = require('./routes/artists');
const genreRoutes = require('./routes/genres');

app.use('/albums', albumRoutes);
app.use('/artists', artistRoutes);
app.use('/genres', genreRoutes);

// Página inicial
app.get('/', (req, res) => {
    res.redirect('/albums');
});

// Iniciar o servidor
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});
