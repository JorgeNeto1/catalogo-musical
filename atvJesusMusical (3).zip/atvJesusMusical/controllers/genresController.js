const Genre = require('../models/genre');

const genreController = {
    // Listar gêneros
    list(req, res) {
        Genre.getAll((err, genres) => {
            if (err) return res.status(500).send('Erro ao listar gêneros.');
            res.render('genres/index', { genres });
        });
    },

    // Exibir formulário para criar gênero
    createForm(req, res) {
        res.render('genres/new');
    },

    // Criar gênero
    create(req, res) {
        Genre.create(req.body, (err) => {
            if (err) return res.status(500).send('Erro ao criar gênero.');
            res.redirect('/genres');
        });
    },

    // Editar gênero
    editForm(req, res) {
        const genreId = req.params.id;
        Genre.findById(genreId, (err, genre) => {
            if (err) return res.status(500).send('Erro ao buscar gênero.');
            res.render('genres/edit', { genre });
        });
    },

    // Atualizar gênero
    update(req, res) {
        const genreId = req.params.id;
        Genre.update(genreId, req.body.name, (err) => {
            if (err) return res.status(500).send('Erro ao atualizar gênero.');
            res.redirect('/genres');
        });
    },

    // Excluir gênero
    delete(req, res) {
        const genreId = req.params.id;
        Genre.delete(genreId, (err) => {
            if (err) return res.status(500).send('Erro ao excluir gênero.');
            res.redirect('/genres');
        });
    },
};

module.exports = genreController;
