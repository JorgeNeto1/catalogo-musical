const Album = require('../models/album');
const Artist = require('../models/artist');
const Genre = require('../models/genre');

const albumController = {
    // Listar todos os álbuns
    list(req, res) {
        Album.getAll((err, albums) => {
            if (err) return res.status(500).send('Erro ao listar álbuns.');
            res.render('albums/index', { albums });
        });
    },

    // Exibir formulário para criar um novo álbum
    createForm(req, res) {
        Artist.getAll((err, artists) => {
            if (err) return res.status(500).send('Erro ao carregar artistas.');
            Genre.getAll((err, genres) => {
                if (err) return res.status(500).send('Erro ao carregar gêneros.');
                res.render('albums/new', { artists, genres });
            });
        });
    },

    // Criar um novo álbum
    create(req, res) {
        Album.create(req.body, (err, albumId) => {
            if (err) return res.status(500).send('Erro ao criar álbum.');
            const genreIds = req.body.genres || [];
            genreIds.forEach((genreId) => {
                Album.addGenre(albumId, genreId, (err) => {
                    if (err) console.error('Erro ao associar gênero:', err);
                });
            });
            res.redirect('/albums');
        });
    },

    // Editar um álbum
    editForm(req, res) {
        const albumId = req.params.id;
        Album.findById(albumId, (err, album) => {
            if (err) return res.status(500).send('Erro ao buscar álbum.');
            Artist.getAll((err, artists) => {
                if (err) return res.status(500).send('Erro ao carregar artistas.');
                Genre.getAll((err, genres) => {
                    if (err) return res.status(500).send('Erro ao carregar gêneros.');
                    res.render('albums/edit', { album, artists, genres });
                });
            });
        });
    },

    // Atualizar um álbum
    update(req, res) {
        const albumId = req.params.id;
        Album.update(albumId, req.body, (err) => {
            if (err) return res.status(500).send('Erro ao atualizar álbum.');
            const genreIds = req.body.genres || [];
            Album.clearGenres(albumId, (err) => {
                if (err) console.error('Erro ao limpar gêneros:', err);
                genreIds.forEach((genreId) => {
                    Album.addGenre(albumId, genreId, (err) => {
                        if (err) console.error('Erro ao associar gênero:', err);
                    });
                });
                res.redirect('/albums');
            });
        });
    },

    // Excluir um álbum
    delete(req, res) {
        const albumId = req.params.id;
        Album.delete(albumId, (err) => {
            if (err) return res.status(500).send('Erro ao excluir álbum.');
            res.redirect('/albums');
        });
    },
};

module.exports = albumController;
