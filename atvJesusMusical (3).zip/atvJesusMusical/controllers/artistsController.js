const Artist = require('../models/artist');

const artistController = {
    // Listar artistas
    list(req, res) {
        Artist.getAll((err, artists) => {
            if (err) return res.status(500).send('Erro ao listar artistas.');
            res.render('artists/index', { artists });
        });
    },

    // Exibir formulário para criar artista
    createForm(req, res) {
        res.render('artists/new');
    },

    // Criar artista
    create(req, res) {
        Artist.create(req.body, (err) => {
            if (err) return res.status(500).send('Erro ao criar artista.');
            res.redirect('/artists');
        });
    },

    // Editar artista
    editForm(req, res) {
        const artistId = req.params.id;
        Artist.findById(artistId, (err, artist) => {
            if (err) return res.status(500).send('Erro ao buscar artista.');
            res.render('artists/edit', { artist });
        });
    },

    // Atualizar artista
    update(req, res) {
        const artistId = req.params.id;
        Artist.update(artistId, req.body, (err) => {
            if (err) return res.status(500).send('Erro ao atualizar artista.');
            res.redirect('/artists');
        });
    },

    // Excluir artista
    delete(req, res) {
        const artistId = req.params.id;
        Artist.delete(artistId, (err) => {
            if (err) return res.status(500).send('Erro ao excluir artista.');
            res.redirect('/artists');
        });
    },
};

module.exports = artistController;
