const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const path = require('path');

// Caminhos
const dbPath = path.resolve('./database/catalog.db');
const setupPath = path.resolve('./database/setup.sql');

// Verificar se o arquivo setup.sql existe
if (!fs.existsSync(setupPath)) {
    console.error("Arquivo setup.sql não encontrado.");
    process.exit(1);
}

// Lê o conteúdo do arquivo setup.sql
const setupSQL = fs.readFileSync(setupPath, 'utf-8');

// Cria ou conecta ao banco de dados
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error("Erro ao conectar ao banco de dados:", err.message);
        process.exit(1);
    }
    console.log("Banco de dados conectado.");
});

// Executa o SQL do setup
db.serialize(() => {
    db.exec(setupSQL, (err) => {
        if (err) {
            console.error("Erro ao inicializar o banco de dados:", err.message);
        } else {
            console.log("Banco de dados inicializado com sucesso.");
        }
    });
});

// Fecha a conexão
db.close((err) => {
    if (err) {
        console.error("Erro ao fechar a conexão com o banco de dados:", err.message);
    } else {
        console.log("Conexão com o banco de dados fechada.");
    }
});
